<?php
include "db2.php";

?>


<html>
<body>
<h1 align="center">Records from table 'cse1'</h1>
<p>
<table border='0' bgcolor="yellow" align="center">
<tr><th>Name</th><th>Email ID</th><th>Mobile Numner</th><th>Address</th><th>Date</th> <th>Appointment Time</th><th>Service Type</th>   </tr>
<?php
								$query = "SELECT * FROM `ser_reg12` WHERE 1";
								$resultset = mysqli_query($con,$query);
								while($row=mysqli_fetch_array($resultset))
								{
								  echo '<tr><td>'.$db_roll=$row['User_name'].'</td><td>'.$db_name=$row['Email'].'</td><td>'.$db_class=$row['Mobile_no'].'</td><td>'.$db_department=$row['Address'].'</td><tr>'.$db_date=$row['Date'].'</td><td>'.$db_time=$row['Appointment_Time'].'</td><tr>'.$db_type=$row['Service_type'].'</td><tr>';
									  
								}
?>
</table>
</p>
</body>
</html>