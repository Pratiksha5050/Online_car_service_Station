<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Track of Patients</title>
    <link rel="stylesheet" href="effect4.css">
</head>
<body>
	<a href="patient_data.php"><button class="button">Go Back</button></a>
	<br><br><h2><span>PATIENTS' HEALTH DETAILS</span></h2>
    <form method="post"><br><br>
    <center>
    <p><input type="text" id="p_id" name="p_id" placeholder= "Patient ID" value="<?php if(isset($_POST['get']))echo $_POST['p_id'];?>" required></input></p>
    <p><input type="submit" name="get" value="Fetch Record"></input></p>
    </center>
    
    <div class="table-responsive">
        <h3><table align="center" border="1">
            <thead>
                <tr>
                    <th>Patient ID</th>
                    <th>Date (YYYY-MM-DD)</th>
                	<th>Illness</th>
                    <th>Blood Pressure (mmHg)</th>
                    <th>Sugar level (mg/dL)</th>
                    <th>Temperature (in C)</th>
                    <th>Haemoglobin (g/dL)</th>


                    <tbody>
                    <?php
                        include "db_connection.php";
                        if(isset($_POST['get']))
						{
                            $p_id=$_POST['p_id'];
                            $selectquerry="SELECT * FROM `health_data` WHERE `Patient ID`='$p_id'";
                            $query = mysqli_query($con,$selectquerry);


                            while($res = mysqli_fetch_array($query))
                            {
                    ?>
                            <tr>
                                <td><?php echo $res['Patient ID']?></td>
                                <td><?php echo $res['Date (YYYY-MM-DD)']?></td>
                                <td><?php echo $res['Illness']?></td>
                                <td><?php echo $res['BP']?></td>
                                <td><?php echo $res['Sugar']?></td>
                                <td><?php echo $res['Temp']?></td>
                                <td><?php echo $res['Hb']?></td>
                            </tr>

                    <?php 
                            }
                        }
                
                    ?>  

                    </tbody>
                </tr>  
            <thead>
        </table></h3>
    </div>
    </form>
</body>
</html>

