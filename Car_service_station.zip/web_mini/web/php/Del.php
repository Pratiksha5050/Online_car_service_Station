<?php
include "db2.php";
if(isset($_POST['submit']))
{
		$roll=$_POST['rn'];
		//$name=$_POST['name'];
		//$class=$_POST['class'];		
		//$dept="CSE";
		
		
		
		$query=" Delete from `ser_mem1` where Email = '$roll'";
		//$resultset=mysqli_query($con,$query);
		if ($con->query($query) === TRUE)
		{
			echo "<script type='text/javascript'>alert('Service deleted Successfully!');</script>";
			echo 'window.location.href = "index.html";';
		}
		else 
		{
			echo "<script type='text/javascript'>alert('Error during deletion!');</script>";
			
		}

	
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="f44.css">
    <title>Service deletion</title>
</head>
<body>
<div class="container-1">
    <form method="post">
        <H3><span>Delete your Service Registration</span></H3>
        <p><input type="text" id="rn" name="rn" placeholder="Enter your Email" value="<?php if(isset($_POST['submit']))echo $_POST['rn'];?>" required></input></p>
        <br><BR><p><input type="submit" name="submit" Value="Delete" required></input></p>
    </form>
</div>


</form>

</body>
<html>