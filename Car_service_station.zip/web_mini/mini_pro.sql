-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2022 at 10:13 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `login1`
--

CREATE TABLE `login1` (
  `Email_Id` varchar(255) NOT NULL,
  `Contact_No` double NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login1`
--

INSERT INTO `login1` (`Email_Id`, `Contact_No`, `Password`) VALUES
('patildipti675@gmail.com', 8669330564, '1234'),
('pallaviyadav123@gmail.com', 1234567890, '1234');

-- --------------------------------------------------------

--
-- Table structure for table `reg_station`
--

CREATE TABLE `reg_station` (
  `station_name` varchar(255) NOT NULL,
  `Contact_No` int(11) NOT NULL,
  `Address` varchar(355) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reg_station`
--

INSERT INTO `reg_station` (`station_name`, `Contact_No`, `Address`) VALUES
('Omkar Service Station', 2147483647, 'A/P Sangali');

-- --------------------------------------------------------

--
-- Table structure for table `ser_mem1`
--

CREATE TABLE `ser_mem1` (
  `User_Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Mobile_no` double NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Appointment_Time` varchar(255) NOT NULL,
  `Service_combo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ser_mem1`
--

INSERT INTO `ser_mem1` (`User_Name`, `Email`, `Mobile_no`, `Address`, `Date`, `Appointment_Time`, `Service_combo`) VALUES
('Dipti Patil', 'patildipti675@gmail.com', 8669330564, 'A/P koparde haveli', '2021-11-24', '1PM-3PM', '2 in 1 combo');

-- --------------------------------------------------------

--
-- Table structure for table `ser_reg12`
--

CREATE TABLE `ser_reg12` (
  `User_Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Mobile_no` double NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `Appointment_Time` varchar(255) NOT NULL,
  `Service_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ser_reg12`
--

INSERT INTO `ser_reg12` (`User_Name`, `Email`, `Mobile_no`, `Address`, `Date`, `Appointment_Time`, `Service_type`) VALUES
('Deepraj Patil', 'deep16@gmail.com', 7435488654, 'A/P Karve', '2021-11-17', '9AM-11AM', 'Car repair service, Price(Rs 180)'),
('Pratiksha Kalokhe', 'kalokhepratiksha5050@gmail.com', 9325125032, 'A/P Ashta', '2021-11-24', '5PM-7PM', 'Car safety feature check, Price(Rs 150)'),
('Komal Pol', 'komal0817@gmail.com', 8967452312, 'A/P Satara', '2021-11-27', '9AM-11AM', 'Break Repair, Price(Rs 200)'),
('Pratiksha Yadav', 'pattu22@gmail.com', 9850998756, 'A/P Wategoan', '2021-11-27', '9AM-11AM', 'Car repair service, Price(Rs 180)');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ser_mem1`
--
ALTER TABLE `ser_mem1`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `ser_reg12`
--
ALTER TABLE `ser_reg12`
  ADD PRIMARY KEY (`Email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
